import React from "react"
import './NaoEncontrado.css'
const NaoEncontrado = props => (
    <div className="erro">
        <h1>Página não encontrada ;-;</h1>
    </div>


)
export default NaoEncontrado